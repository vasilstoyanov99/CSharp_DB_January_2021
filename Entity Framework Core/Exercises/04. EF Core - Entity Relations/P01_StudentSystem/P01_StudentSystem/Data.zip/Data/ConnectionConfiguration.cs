﻿namespace P01_StudentSystem.Data
{
    internal class ConnectionConfiguration
    { 
        internal static string ConnectionString = 
            @"Server=.;Database=StudentSystem;Integrated Security= true;";
    }
}
