﻿namespace P03_FootballBetting.Data
{
    public static class ConnectionConfiguration
    {
        public const string ConnectionString
            = @"Server=.;Database=FootballBettingSystem;Integrated Security=true;";
    }
}
